class ListaSimulada:
    def __init__(self):
        self.lista = []

    def crear_lista_vacia(self):
     
        self.lista = []

    def mostrar_listado_elementos(self):

        return self.lista

    def insertar_elemento_en_lista(self, valor):
     
        self.lista.append(valor)

    def remover_elemento(self):
      
        if self.lista:
            self.lista.pop(0)

# Ejemplo de uso
lista_simulada = ListaSimulada()
lista_simulada.crear_lista_vacia()
print("Lista después de crearla vacía:", lista_simulada.mostrar_listado_elementos())

lista_simulada.insertar_elemento_en_lista(5)
lista_simulada.insertar_elemento_en_lista(10)
lista_simulada.insertar_elemento_en_lista(15)
print("Lista después de insertar elementos:", lista_simulada.mostrar_listado_elementos())

lista_simulada.remover_elemento()
print("Lista después de remover el primer elemento:", lista_simulada.mostrar_listado_elementos())
