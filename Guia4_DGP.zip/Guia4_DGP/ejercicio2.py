import random

def generar_matriz_aleatoria(limite_inferior, limite_superior):
   
    matriz = []
    for _ in range(5):
        fila = [random.randint(limite_inferior, limite_superior) for _ in range(5)]
        matriz.append(fila)
    return matriz

def recibir_matriz(matriz):
   
    for fila in matriz:
        print(fila)

# Ejemplo de uso:
limite_inferior = 1
limite_superior = 10
matriz = generar_matriz_aleatoria(limite_inferior, limite_superior)
recibir_matriz(matriz)
