def calcular_estadisticas_notas(notas):

    total_estudiantes = len(notas)
    deficientes = len([nota for nota in notas if nota < 5.0])
    aprobados = len([nota for nota in notas if nota >= 6.0])
    nota_minima = min(notas)
    nota_maxima = max(notas)
    nota_media = sum(notas) / total_estudiantes

    porcentaje_deficientes = (deficientes / total_estudiantes) * 100

    estadisticas = {
        "Porcentaje de estudiantes Deficientes": porcentaje_deficientes,
        "Número de aprobados": aprobados,
        "Nota más baja": nota_minima,
        "Nota más alta": nota_maxima,
        "Nota media": nota_media
    }

    return estadisticas
def mostrar_estadisticas_en_listbox(notas, listbox):

    estadisticas = calcular_estadisticas_notas(notas)
    listbox.append(f"Porcentaje de estudiantes Deficientes: {estadisticas['Porcentaje de estudiantes Deficientes']:.2f}%")
    listbox.append(f"Número de aprobados: {estadisticas['Número de aprobados']}")
    listbox.append(f"Nota más baja: {estadisticas['Nota más baja']}")
    listbox.append(f"Nota más alta: {estadisticas['Nota más alta']}")
    listbox.append(f"Nota media: {estadisticas['Nota media']:.2f}")

notas = [4.5, 6.7, 8.9, 3.2, 5.5, 9.0, 7.1, 4.9, 10.0, 2.3]
listbox = []

mostrar_estadisticas_en_listbox(notas, listbox)

for item in listbox:
    print(item)
